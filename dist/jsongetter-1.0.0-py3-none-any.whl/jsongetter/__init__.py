# jsongetter/__init__.py
from .jsongetter import JsonGetter
from .node import Node
__all__ = ['JsonGetter', 'Node']
__version__ = "1.0.0"
